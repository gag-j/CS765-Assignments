sleep 5s
geth attach $HOME/HW3/test-eth"$1"/geth.ipc
